using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hot3.Areas.Admin.Views.Products
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
