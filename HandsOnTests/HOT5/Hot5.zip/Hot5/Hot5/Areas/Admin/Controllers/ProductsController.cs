﻿using Hot3.Data;
using Hot3.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Hot3.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("admin/products")]
    [Authorize(Roles = "Admin")]
    public class ProductsController : Controller
    {
        private readonly AppDbContext _db;
        public ProductsController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var list = await _db.Products.ToListAsync();
            return View(list);
        }

        [HttpGet("create/")]
        public IActionResult Create() => View();

        [HttpPost("create/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product model)
        {
            if (!ModelState.IsValid) return View(model);

            // basic slug uniqueness check
            if (await _db.Products.AnyAsync(p => p.Slug == model.Slug))
            {
                ModelState.AddModelError("Slug", "Slug must be unique.");
                return View(model);
            }

            _db.Products.Add(model);
            await _db.SaveChangesAsync();
            TempData["success"] = "Product created.";
            return RedirectToAction("Index");
        }

        [HttpGet("edit/{slug}/")]
        public async Task<IActionResult> Edit(string slug)
        {
            var product = await _db.Products.FirstOrDefaultAsync(x => x.Slug == slug);

            if (product == null)
            {
                TempData["error"] = "Product not found.";
                return RedirectToAction("Index");
            }

            return View(product);
        }

        [HttpPost("edit/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string slug, Product model)
        {

            if (!ModelState.IsValid)
            {
                Console.WriteLine("ModelState Invalid. Errors:");
                foreach (var error in ModelState)
                {
                    foreach (var subError in error.Value.Errors)
                        Console.WriteLine($" - {error.Key}: {subError.ErrorMessage}");
                }
                return View(model);
            }

            var p = await _db.Products.FirstOrDefaultAsync(x => x.Id == model.Id);
            if (p == null)
            {
                Console.WriteLine($"No product found with ID={model.Id}");
                return NotFound();
            }


            bool slugExists = await _db.Products.AnyAsync(x => x.Slug == model.Slug && x.Id != model.Id);

            if (slugExists)
            {
                ModelState.AddModelError("Slug", "Slug must be unique.");
                return View(model);
            }

            // Apply updates
            p.Name = model.Name;
            p.Slug = model.Slug;
            p.Category = model.Category;
            p.Price = model.Price;
            p.Stock = model.Stock;
            p.Description = model.Description;

            await _db.SaveChangesAsync();
            TempData["success"] = "Product updated successfully!";

            return RedirectToAction("Index");
        }


        [HttpPost("delete/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string slug)
        {
            var p = await _db.Products.FirstOrDefaultAsync(x => x.Slug == slug);
            if (p == null) return NotFound();
            _db.Products.Remove(p);
            await _db.SaveChangesAsync();
            TempData["warning"] = "Product deleted.";
            return RedirectToAction("Index");
        }
    }
}
