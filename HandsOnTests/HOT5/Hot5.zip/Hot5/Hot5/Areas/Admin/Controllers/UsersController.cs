﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using Hot3.Models;
using Hot3.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;

namespace Hot3.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    [Route("admin/users")]
    public class UsersController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UsersController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // GET admin/users
        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var list = new List<UserWithRolesViewModel>();

            foreach (var user in _userManager.Users.ToList())
            {
                var roles = await _userManager.GetRolesAsync(user);
                list.Add(new UserWithRolesViewModel { User = user, Roles = roles });
            }

            return View(list);
        }

        // POST admin/users/create-admin-role
        [HttpPost("create-admin-role")]
        public async Task<IActionResult> CreateAdminRole()
        {
            if (!await _roleManager.RoleExistsAsync("Admin"))
                await _roleManager.CreateAsync(new IdentityRole("Admin"));

            TempData["success"] = "Admin role created (or already exists).";
            return RedirectToAction("Index");
        }

        // POST admin/users/delete/{id}
        [HttpPost("delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            var res = await _userManager.DeleteAsync(user);
            TempData["warning"] = res.Succeeded ? "User deleted." : "Delete failed.";
            return RedirectToAction("Index");
        }

        // POST admin/users/add-admin/{id}
        [HttpPost("add-admin/{id}")]
        public async Task<IActionResult> AddAdmin(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            if (!await _roleManager.RoleExistsAsync("Admin"))
                await _roleManager.CreateAsync(new IdentityRole("Admin"));

            await _userManager.AddToRoleAsync(user, "Admin");
            TempData["success"] = "User added to Admin role.";
            return RedirectToAction("Index");
        }

        // POST admin/users/remove-admin/{id}
        [HttpPost("remove-admin/{id}")]
        public async Task<IActionResult> RemoveAdmin(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            await _userManager.RemoveFromRoleAsync(user, "Admin");
            TempData["warning"] = "Admin role removed from user.";
            return RedirectToAction("Index");
        }
    }
}
