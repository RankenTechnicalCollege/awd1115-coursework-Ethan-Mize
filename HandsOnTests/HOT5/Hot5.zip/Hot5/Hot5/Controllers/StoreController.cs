﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Hot3.Data;

namespace Hot3.Controllers
{
    public class StoreController : Controller
    {
        private readonly AppDbContext _db;
        public StoreController(AppDbContext db) { _db = db; }

        // Home: List all entities, filter by category query param
        [HttpGet("/")]
        public async Task<IActionResult> Index([FromQuery] string? category)
        {
            var q = _db.Products.AsQueryable();
            if (!string.IsNullOrEmpty(category))
                q = q.Where(p => p.Category.ToLower() == category.ToLower());

            var products = await q.ToListAsync();
            ViewBag.SelectedCategory = category;
            return View(products);
        }

        // Show single product (view all fields and picture)
        [HttpGet("product/{slug}/")]
        public async Task<IActionResult> Details(string slug)
        {
            var product = await _db.Products.FirstOrDefaultAsync(p => p.Slug == slug);
            if (product == null) return NotFound();
            return View(product);
        }
    }
}
