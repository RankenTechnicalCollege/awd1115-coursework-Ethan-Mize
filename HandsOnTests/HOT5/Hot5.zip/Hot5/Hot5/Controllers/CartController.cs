﻿using Hot3.Data;
using Hot3.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace Hot3.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        private readonly AppDbContext _db;
        private const string SessionKey = "cart";

        public CartController(AppDbContext db) { _db = db; }

        private CartViewModel GetCartFromSession()
        {
            var json = HttpContext.Session.GetString(SessionKey);
            if (string.IsNullOrEmpty(json)) return new CartViewModel();
            return JsonSerializer.Deserialize<CartViewModel>(json) ?? new CartViewModel();
        }

        private void SaveCartToSession(CartViewModel cart)
        {
            HttpContext.Session.SetString(SessionKey, JsonSerializer.Serialize(cart));
        }

        [HttpGet("/cart/")]
        public IActionResult Index()
        {
            var cart = GetCartFromSession();
            return View(cart);
        }

        [HttpPost("/cart/add/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(int productId, int quantity = 1)
        {
            var product = await _db.Products.FindAsync(productId);
            if (product == null) return NotFound();

            var cart = GetCartFromSession();
            var item = cart.Items.FirstOrDefault(i => i.ProductId == productId);
            if (item == null)
            {
                cart.Items.Add(new CartItemViewModel
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    UnitPrice = product.Price,
                    Quantity = quantity,
                    ImageFileName = product.ImageFileName
                });
            }
            else
            {
                item.Quantity += quantity;
            }
            SaveCartToSession(cart);
            TempData["success"] = $"{product.Name} added to cart.";
            return Redirect(Request.Headers["Referer"].ToString() ?? "/");
        }

        [HttpPost("/cart/remove/")]
        [ValidateAntiForgeryToken]
        public IActionResult Remove(int productId)
        {
            var cart = GetCartFromSession();
            var item = cart.Items.FirstOrDefault(i => i.ProductId == productId);
            if (item != null)
            {
                cart.Items.Remove(item);
                SaveCartToSession(cart);
                TempData["warning"] = $"{item.ProductName} removed from cart.";
            }
            return RedirectToAction("Index");
        }

        [HttpPost("/cart/checkout/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout()
        {
            var cart = GetCartFromSession();
            if (!cart.Items.Any())
            {
                TempData["warning"] = "Cart is empty.";
                return RedirectToAction("Index");
            }

            var order = new Hot3.Models.Order
            {
                CreatedAt = DateTime.UtcNow,
                UserIdentifier = HttpContext.Session.Id,
                Total = cart.TotalPrice
            };

            foreach (var it in cart.Items)
            {
                order.Items.Add(new Hot3.Models.OrderItem
                {
                    ProductId = it.ProductId,
                    Quantity = it.Quantity,
                    UnitPrice = it.UnitPrice
                });

                // Optionally decrease product stock
                var product = await _db.Products.FindAsync(it.ProductId);
                if (product != null)
                {
                    product.Stock = Math.Max(0, product.Stock - it.Quantity);
                }
            }

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();

            // Clear session cart
            HttpContext.Session.Remove(SessionKey);
            TempData["success"] = "Purchase completed successfully.";
            return RedirectToAction("Index", "Store");
        }
    }
}
