using Hot3.Data;
using Hot3.Services;
using Hot3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Routing;
using System;



// ----------------------------
// 1) Create builder
// ----------------------------
var builder = WebApplication.CreateBuilder(args);

// ----------------------------
// 2) Add services to the container
// ----------------------------
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages(); // Needed for Identity scaffolded pages

// ----------------------------
// 3) Add DbContext
// ----------------------------
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


// ----------------------------
// 4) Add Identity
// ----------------------------
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.SignIn.RequireConfirmedAccount = false;

    // Password rules
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 6;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireNonAlphanumeric = false;
})
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

// ----------------------------
// 5) Dummy email sender for dev
// ----------------------------
builder.Services.AddSingleton<IEmailSender, DummyEmailSender>();

// ----------------------------
// 6) Configure cookie login paths
// ----------------------------
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Identity/Account/Login";
    options.AccessDeniedPath = "/Identity/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromDays(30);
});

// ----------------------------
// 7) Sessions
// ----------------------------
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromHours(2);
});

// ----------------------------
// 8) Routing options
// ----------------------------
builder.Services.Configure<RouteOptions>(options =>
{
    options.LowercaseUrls = true;
    options.AppendTrailingSlash = true;
});

// ----------------------------
// 9) Build app
// ----------------------------
var app = builder.Build();

// ----------------------------
// 10) Seed Admin Role + Account
// ----------------------------
using (var scope = app.Services.CreateScope())
{
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

    string adminRole = "Admin";
    string adminUser = "admin";
    string adminPass = "Admin123";

    if (!await roleManager.RoleExistsAsync(adminRole))
    {
        await roleManager.CreateAsync(new IdentityRole(adminRole));
    }

    var existingAdmin = await userManager.FindByEmailAsync("admin@example.com");
    if (existingAdmin == null)
    {
        var newAdmin = new ApplicationUser
        {
            UserName = "admin@example.com", // Important: login uses UserName by default
            Email = "admin@example.com",
            FirstName = "System",
            LastName = "Admin",
            EmailConfirmed = true // Mark email confirmed to allow login
        };

        var result = await userManager.CreateAsync(newAdmin, adminPass);

        if (result.Succeeded)
        {
            await userManager.AddToRoleAsync(newAdmin, adminRole);
        }
    }
}
    // ----------------------------
    // 11) Middleware / pipeline
    // ----------------------------
    if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication(); // Auth BEFORE MVC routing
app.UseAuthorization();

app.UseSession();

// ----------------------------
// 12) Routes
// ----------------------------
app.MapAreaControllerRoute(
    name: "Admin",
    areaName: "Admin",
    pattern: "admin/{controller=Home}/{action=Index}/{id?}/"
);

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Store}/{action=Index}/{id?}/"
);

app.MapRazorPages(); // Identity scaffolded pages

// ----------------------------
// 13) Run
// ----------------------------
app.Run();
