﻿using Hot3.Models;
using System.Collections.Generic;

namespace Hot3.Models.ViewModels
{
    public class UserWithRolesViewModel
    {
        public ApplicationUser User { get; set; } = null!;
        public IList<string> Roles { get; set; } = new List<string>();
    }
}
