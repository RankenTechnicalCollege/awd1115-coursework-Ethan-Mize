﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using Hot3.Models;

namespace Hot3.Data
{
    public static class IdentitySeed
    {
        public static async Task SeedAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            // Ensure Admin role exists
            var roleExists = await roleManager.RoleExistsAsync("Admin");
            if (!roleExists)
                await roleManager.CreateAsync(new IdentityRole("Admin"));

            // Create admin user
            var adminUserName = "admin";
            var adminEmail = "admin@example.com"; // change if you want
            var admin = await userManager.FindByNameAsync(adminUserName);
            if (admin == null)
            {
                var user = new ApplicationUser
                {
                    UserName = adminUserName,
                    Email = adminEmail,
                    FirstName = "System",
                    LastName = "Administrator",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(user, "Admin123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(user, "Admin");
                }
                else
                {
                    // optionally log errors
                    foreach (var e in result.Errors)
                    {
                        Console.WriteLine(e.Description);
                    }
                }
            }
            else
            {
                // ensure role
                if (!await userManager.IsInRoleAsync(admin, "Admin"))
                    await userManager.AddToRoleAsync(admin, "Admin");
            }
        }
    }
}
