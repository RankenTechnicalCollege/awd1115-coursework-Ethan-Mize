﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Hot3.Models;

namespace Hot3.Data
{
    public class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> opts) : base(opts) { }

        public DbSet<Product> Products { get; set; } = null!;
        public DbSet<Order> Orders { get; set; } = null!;
        public DbSet<OrderItem> OrderItems { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // IMPORTANT: Identity tables mapping

            // Seed 5 products (IDs fixed for simplicity)
            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Minimal Leather Wallet", Slug = "minimal-leather-wallet", ImageFileName = "wallet.jpg", Category = "accessories", Price = 19.99m, Stock = 25, Description = "Slim leather wallet" },
                new Product { Id = 2, Name = "Canvas Tote Bag", Slug = "canvas-tote-bag", ImageFileName = "tote.jpg", Category = "bags", Price = 24.50m, Stock = 40, Description = "Eco-friendly tote" },
                new Product { Id = 3, Name = "Wireless Earbuds", Slug = "wireless-earbuds", ImageFileName = "earbuds.jpg", Category = "electronics", Price = 49.99m, Stock = 60, Description = "Bluetooth earbuds" },
                new Product { Id = 4, Name = "Ceramic Coffee Mug", Slug = "ceramic-coffee-mug", ImageFileName = "mug.jpg", Category = "home", Price = 12.00m, Stock = 80, Description = "12oz ceramic mug" },
                new Product { Id = 5, Name = "Scented Candle", Slug = "scented-candle", ImageFileName = "candle.jpg", Category = "home", Price = 15.00m, Stock = 30, Description = "Lavender candle" }
            );
        }
    }
}
