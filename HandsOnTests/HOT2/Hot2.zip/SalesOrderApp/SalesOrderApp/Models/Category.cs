﻿using System.ComponentModel.DataAnnotations;

namespace SalesOrderApp.Models
{
    public class Category
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Category name is required.")]
        public string CategoryName { get; set; }

        public Product Product { get; set; }  // One-to-one relationship
    }
}
