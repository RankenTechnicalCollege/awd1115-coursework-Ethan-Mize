﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesOrderApp.Data;
using SalesOrderApp.Models;
using System.Text.RegularExpressions;

namespace SalesOrderApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Helper method to create URL-friendly slugs from product names
        private string CreateSlug(string productName)
        {
            if (string.IsNullOrEmpty(productName)) return "";

            // Convert to lowercase and replace spaces/special chars with hyphens
            string slug = productName.ToLower();
            slug = Regex.Replace(slug, @"[^a-z0-9\s-]", "");
            slug = Regex.Replace(slug, @"\s+", "-");
            slug = Regex.Replace(slug, @"-+", "-");
            return slug.Trim('-');
        }

        // Show all products
        public async Task<IActionResult> List()
        {
            var products = _context.Products
             .Include(p => p.Category)
             .ToList();
            return View(products);
        }

        // GET: Create new product
        public async Task<IActionResult> Create()
        {
            ViewBag.Categories = await _context.Categories.ToListAsync();
            return View();
        }

        // POST: Create new product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            // Remove Category navigation property validation if it exists
            if (ModelState.ContainsKey("Category"))
            {
                ModelState.Remove("Category");
            }

            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(List));
            }

            // IMPORTANT: Repopulate ViewBag.Categories before returning the view
            ViewBag.Categories = await _context.Categories.ToListAsync();
            return View(product);
        }

        // GET: Edit product (now supports slug in URL)
        public async Task<IActionResult> Edit(int id, string slug = null)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null) return NotFound();

            // Verify slug matches product name (redirect if incorrect)
            string expectedSlug = CreateSlug(product.ProductName);
            if (!string.IsNullOrEmpty(slug) && slug != expectedSlug)
            {
                return RedirectToAction(nameof(Edit), new { id = id, slug = expectedSlug });
            }

            ViewBag.Categories = await _context.Categories.ToListAsync();
            return View(product);
        }

        // POST: Edit product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            if (id != product.ProductID) return NotFound();

            // Remove Category navigation property validation since we're only using CategoryID
            if (ModelState.ContainsKey("Category"))
            {
                ModelState.Remove("Category");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = await _context.Categories.ToListAsync();
                return View(product);
            }

            try
            {
                var existingProduct = await _context.Products.FindAsync(id);
                if (existingProduct == null) return NotFound();

                // Update only the editable fields
                existingProduct.ProductName = product.ProductName;
                existingProduct.ProductDescShort = product.ProductDescShort;
                existingProduct.ProductDescLong = product.ProductDescLong;
                existingProduct.ProductPrice = product.ProductPrice;
                existingProduct.ProductQty = product.ProductQty;
                existingProduct.CategoryID = product.CategoryID;

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(List));
            }
            catch (DbUpdateException ex)
            {
                ModelState.AddModelError("", "Unable to save changes: " + ex.Message);
                ViewBag.Categories = await _context.Categories.ToListAsync();
                return View(product);
            }
        }

        // GET: Delete product (now supports slug in URL)
        public async Task<IActionResult> Delete(int? id, string slug = null)
        {
            if (id == null) return NotFound();

            var product = await _context.Products.Include(p => p.Category)
                .FirstOrDefaultAsync(m => m.ProductID == id);

            if (product == null) return NotFound();

            // Verify slug matches product name (redirect if incorrect)
            string expectedSlug = CreateSlug(product.ProductName);
            if (!string.IsNullOrEmpty(slug) && slug != expectedSlug)
            {
                return RedirectToAction(nameof(Delete), new { id = id, slug = expectedSlug });
            }

            return View(product);
        }

        // POST: Confirm delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(List));
        }
    }
}