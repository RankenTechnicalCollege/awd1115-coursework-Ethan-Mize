using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesOrderApp.Views.Products
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
