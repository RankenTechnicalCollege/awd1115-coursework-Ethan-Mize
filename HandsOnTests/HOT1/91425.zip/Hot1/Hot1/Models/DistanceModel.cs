﻿using System.ComponentModel.DataAnnotations;

namespace Hot1.Models
{
    public class DistanceModel
    {
        [Required(ErrorMessage = "Please enter a distance in inches.")]
        [Range(1, 500, ErrorMessage = "Distance must be between {1} and {2} inches.")]
        [Display(Name = "Distance (inches)")]
        public decimal? Inches { get; set; }

        // Filled by controller; not user-editable
        public decimal Centimeters { get; set; }
    }
}
