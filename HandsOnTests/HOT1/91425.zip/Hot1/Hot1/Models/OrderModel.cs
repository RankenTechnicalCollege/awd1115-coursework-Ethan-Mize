﻿using System.ComponentModel.DataAnnotations;

namespace Hot1.Models
{
    public class OrderModel
    {
        [Required(ErrorMessage = "Please enter a quantity.")]
        [Range(1, 100, ErrorMessage = "Quantity must be between {1} and {2}.")]
        public int? Quantity { get; set; }

        [Display(Name = "Discount Code (optional)")]
        public string? DiscountCode { get; set; }

        // Calculated fields (filled in controller)
        public decimal Subtotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal Tax { get; set; }
        public decimal Total { get; set; }

        // Error message if discount code invalid
        public string? DiscountError { get; set; }
    }
}
