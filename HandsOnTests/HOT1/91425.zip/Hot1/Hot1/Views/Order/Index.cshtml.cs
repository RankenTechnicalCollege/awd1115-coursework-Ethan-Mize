using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hot1.Views.Order
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
