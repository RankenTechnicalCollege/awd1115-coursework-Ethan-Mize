﻿using Hot1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hot1.Controllers
{
    public class OrderController : Controller
    {
        private const decimal ShirtPrice = 15m;
        private const decimal TaxRate = 0.08m;

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(OrderModel model)
        {
            if (ModelState.IsValid)
            {
                // Step 1: Calculate subtotal
                model.Subtotal = model.Quantity.Value * ShirtPrice;

                // Step 2: Apply discount if valid
                decimal discountRate = 0;
                switch (model.DiscountCode?.Trim().ToUpper())
                {
                    case "6175":
                        discountRate = 0.30m;
                        break;
                    case "1390":
                        discountRate = 0.20m;
                        break;
                    case "BB88":
                        discountRate = 0.10m;
                        break;
                    case null:
                    case "":
                        break; // no code entered
                    default:
                        model.DiscountError = "Invalid discount code. No discount applied.";
                        break;
                }

                model.DiscountAmount = model.Subtotal * discountRate;

                // Step 3: Apply tax
                decimal discountedSubtotal = model.Subtotal - model.DiscountAmount;
                model.Tax = discountedSubtotal * TaxRate;

                // Step 4: Final total
                model.Total = discountedSubtotal + model.Tax;
            }

            return View(model);
        }
    }
}
