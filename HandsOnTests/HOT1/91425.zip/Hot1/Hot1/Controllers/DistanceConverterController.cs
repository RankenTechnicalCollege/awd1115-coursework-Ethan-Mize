﻿using Microsoft.AspNetCore.Mvc;
using Hot1.Models;
using System;

namespace Hot1.Controllers
{
    public class DistanceConverterController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new DistanceModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(DistanceModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            model.Centimeters = Math.Round(model.Inches.GetValueOrDefault() * 2.54m, 2);

            return View(model);
        }
    }
}
