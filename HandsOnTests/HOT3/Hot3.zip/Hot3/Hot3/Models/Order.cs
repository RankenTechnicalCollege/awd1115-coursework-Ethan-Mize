﻿namespace Hot3.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public string? UserIdentifier { get; set; } // for demo, could be session id
        public List<OrderItem> Items { get; set; } = new();
        public decimal Total { get; set; }
    }
}
