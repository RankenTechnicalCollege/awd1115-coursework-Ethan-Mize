﻿using System.ComponentModel.DataAnnotations;

namespace Hot3.Models
{
    public class Product
    {
        public int Id { get; set; } // primary key

        [Required, StringLength(100)]
        public string Name { get; set; } = "";

        [Required, RegularExpression(@"^[a-z0-9\-]+$",
          ErrorMessage = "Slug must be lowercase letters, numbers and hyphens.")]
        public string Slug { get; set; } = ""; // use in URLs (must be unique ideally)

        public string ImageFileName { get; set; } = ""; // store filename

        // ----- custom fields -----
        [Required]
        public string Category { get; set; } = "";

        [Range(0.0, 100000.0)]
        public decimal Price { get; set; }

        [Range(0, int.MaxValue)]
        public int Stock { get; set; }

        // extra field
        public string Description { get; set; } = "";
    }
}
