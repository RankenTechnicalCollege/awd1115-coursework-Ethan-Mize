﻿namespace Hot3.Models.ViewModels
{
    public class CartItemViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = "";
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public string ImageFileName { get; set; } = "";
    }

    public class CartViewModel
    {
        public List<CartItemViewModel> Items { get; set; } = new();
        public int TotalQuantity => Items.Sum(i => i.Quantity);
        public decimal TotalPrice => Items.Sum(i => i.UnitPrice * i.Quantity);
    }
}
