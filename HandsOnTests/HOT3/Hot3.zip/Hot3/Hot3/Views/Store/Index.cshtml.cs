using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hot3.Views.Store
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
