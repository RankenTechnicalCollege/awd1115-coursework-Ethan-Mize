using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hot3.Views.Cart
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
