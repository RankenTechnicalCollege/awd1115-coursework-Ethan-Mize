using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hot3.Areas.Admin.Views.Products
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
