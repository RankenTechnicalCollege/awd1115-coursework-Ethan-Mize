﻿using System.ComponentModel.DataAnnotations;

namespace PriceQuotation.Models
{
    public class TipCalculatorModel
    {
        [Required(ErrorMessage = "Meal cost is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Meal cost must be greater than 0")]
        public decimal? MealCost { get; set; }

        // Helper method to calculate tip
        public decimal CalculateTip(decimal percent)
        {
            return (MealCost ?? 0) * percent;
        }
    }
}
