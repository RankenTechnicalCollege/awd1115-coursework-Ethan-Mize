﻿using Microsoft.AspNetCore.Mvc;

namespace PriceQuotation.Models
{
    public class PriceQuotationModel
    {
        public decimal? Subtotal { get; set; }
        public decimal? DiscountPercent { get; set; }

        public decimal DiscountAmount
            => (Subtotal ?? 0) * (DiscountPercent ?? 0) / 100m;

        public decimal Total
            => (Subtotal ?? 0) - DiscountAmount;
    }
}

