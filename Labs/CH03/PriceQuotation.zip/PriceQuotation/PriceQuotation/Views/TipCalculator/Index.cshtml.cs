using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PriceQuotation.Views.TipCalculator
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
