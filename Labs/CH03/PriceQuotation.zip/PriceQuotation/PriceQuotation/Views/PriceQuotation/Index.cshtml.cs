using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PriceQuotation.Views.PriceQuotation
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
