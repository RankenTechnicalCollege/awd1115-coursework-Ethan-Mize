﻿using Microsoft.AspNetCore.Mvc;
using PriceQuotation.Models;

namespace PriceQuotation.Controllers
{
    public class PriceQuotationController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            // Start with empty inputs and $0.00 outputs
            var model = new PriceQuotationModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(PriceQuotationModel model)
        {
            // Server-side validation
            if (!model.Subtotal.HasValue || model.Subtotal <= 0)
            {
                ModelState.AddModelError(nameof(model.Subtotal),
                    "Subtotal is required and must be greater than 0.");
            }

            if (!model.DiscountPercent.HasValue ||
                model.DiscountPercent < 0 || model.DiscountPercent > 100)
            {
                ModelState.AddModelError(nameof(model.DiscountPercent),
                    "Discount percent is required and must be between 0 and 100.");
            }

            // If invalid, show validation summary above the form
            if (!ModelState.IsValid) return View(model);

            // Valid → calculated values are read-only properties on the model
            return View(model);
        }

        [HttpGet]
        public IActionResult Clear()
        {
            // Reset to initial state
            return RedirectToAction(nameof(Index));
        }
    }
}
