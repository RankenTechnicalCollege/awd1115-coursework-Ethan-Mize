﻿using Microsoft.AspNetCore.Mvc;
using PriceQuotation.Models;
namespace PriceQuotation.Controllers
{
    public class TipCalculatorController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            // Empty model initially
            return View(new TipCalculatorModel());
        }

        [HttpPost]
        public IActionResult Index(TipCalculatorModel model)
        {
            if (!ModelState.IsValid)
            {
                // Invalid input → show errors + keep tips at $0.00
                model.MealCost = null;
            }
            return View(model);
        }

        public IActionResult Clear()
        {
            return RedirectToAction(nameof(Index));
        }
    }
}