﻿using FAQ.Models;
using System.Collections.Generic;

namespace FAQ.ViewModels
{
        public class FaqIndexViewModel
        {
            public List<Faq> Faqs { get; set; }
            public List<Category> Categories { get; set; }
            public List<Topic> Topics { get; set; }
            public string SelectedCategoryId { get; set; }
            public string SelectedTopicId { get; set; }
        }
}
