﻿using System.ComponentModel.DataAnnotations;

namespace FAQ.Models
{
    public class Topic
    {
        // URL-friendly string primary key, e.g. "payments"
        [Key]
        public string Id { get; set; }

        [Required]
        public string Name { get; set; }

        public ICollection<Faq> Faqs { get; set; }
    }
}
