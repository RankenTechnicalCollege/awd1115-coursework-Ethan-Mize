﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FAQ.Models
{
    public class Faq
    {
        // DB-generated primary key
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string Question { get; set; }

        [Required]
        public string Answer { get; set; }

        // Foreign keys (string keys pointing to Category and Topic)
        [Required]
        public string CategoryId { get; set; }
        public Category Category { get; set; }

        [Required]
        public string TopicId { get; set; }
        public Topic Topic { get; set; }
    }
}
