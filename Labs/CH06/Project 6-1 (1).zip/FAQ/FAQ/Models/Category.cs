﻿using System.ComponentModel.DataAnnotations;

namespace FAQ.Models
{
    public class Category
    {
        // URL-friendly string primary key, e.g. "billing"
        [Key]
        public string Id { get; set; }

        [Required]
        public string Name { get; set; }

        public ICollection<Faq> Faqs { get; set; }
    }
}
