﻿using FAQ.Data;
using FAQ.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FAQ.Controllers
{
    [Route("faqs")]
    public class FaqController : Controller
    {
        private readonly AppDbContext _context;
        public FaqController(AppDbContext context) => _context = context;

        // Multiple route templates map to the same action — static segments distinguish topic vs category
        [HttpGet("", Name = "Faqs_All")]
        [HttpGet("category/{categoryId}/", Name = "Faqs_ByCategory")]
        [HttpGet("topic/{topicId}/", Name = "Faqs_ByTopic")]
        [HttpGet("category/{categoryId}/topic/{topicId}/", Name = "Faqs_ByCategoryThenTopic")]
        [HttpGet("topic/{topicId}/category/{categoryId}/", Name = "Faqs_ByTopicThenCategory")]
        public async Task<IActionResult> Index(string categoryId, string topicId)
        {
            var query = _context.Faqs
                        .Include(f => f.Category)
                        .Include(f => f.Topic)
                        .AsQueryable();

            if (!string.IsNullOrEmpty(categoryId))
                query = query.Where(f => f.CategoryId == categoryId);

            if (!string.IsNullOrEmpty(topicId))
                query = query.Where(f => f.TopicId == topicId);

            var model = new FaqIndexViewModel
            {
                Faqs = await query.OrderBy(f => f.Question).ToListAsync(),
                Categories = await _context.Categories.OrderBy(c => c.Name).ToListAsync(),
                Topics = await _context.Topics.OrderBy(t => t.Name).ToListAsync(),
                SelectedCategoryId = categoryId,
                SelectedTopicId = topicId
            };

            return View(model);
        }
    }
}
