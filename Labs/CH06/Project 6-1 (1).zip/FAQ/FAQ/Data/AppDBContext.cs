﻿using FAQ.Models;
using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;

namespace FAQ.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Faq> Faqs { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Topic> Topics { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Define keys explicitly (optional - conventions handle it)
            modelBuilder.Entity<Category>().HasKey(c => c.Id);
            modelBuilder.Entity<Topic>().HasKey(t => t.Id);
            modelBuilder.Entity<Faq>().HasKey(f => f.Id);

            // Seed example data (IDs must be provided for HasData)
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = "history", Name = "History" }
            );

            modelBuilder.Entity<Topic>().HasData(
                new Topic { Id = "bootstrap", Name = "Bootstrap" },
                new Topic { Id = "csharp", Name = "C#" },
                new Topic { Id = "javascript", Name = "JavaScript" }
            );

            modelBuilder.Entity<Faq>().HasData(
        // Bootstrap
        new Faq { Id = 1, Question = "What is Bootstrap used for?", Answer = "Bootstrap is a front-end framework for responsive websites.", CategoryId = "history", TopicId = "bootstrap" },
        new Faq { Id = 2, Question = "How do I include Bootstrap?", Answer = "Use CDN or install via npm/yarn.", CategoryId = "history", TopicId = "bootstrap" },

        // C#
        new Faq { Id = 3, Question = "What is C# mainly used for?", Answer = "C# is used for apps, services, and game development.", CategoryId = "history", TopicId = "csharp" },
        new Faq { Id = 4, Question = "Difference between ref and out?", Answer = "ref needs initialization, out must be assigned inside.", CategoryId = "history", TopicId = "csharp" },

        // JavaScript
        new Faq { Id = 5, Question = "What is JavaScript used for?", Answer = "For interactivity and dynamic content on websites.", CategoryId = "history", TopicId = "javascript" },
        new Faq { Id = 6, Question = "Difference between let, const, and var?", Answer = "var is function-scoped; let/const are block-scoped.", CategoryId = "history", TopicId = "javascript" }
            );
        }
    }
}
