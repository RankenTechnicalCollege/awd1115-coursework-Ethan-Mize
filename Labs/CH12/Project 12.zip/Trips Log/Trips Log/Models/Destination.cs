﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Trips_Log.Models
{
    public class Destination
    {
        public int DestinationId { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        // Navigation property: one Destination → many Trips
        public ICollection<Trip>? Trips { get; set; }
    }
}
