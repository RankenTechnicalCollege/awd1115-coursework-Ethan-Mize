﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Trips_Log.Models
{
    public class Trip
    {
        [Key]
        public int TripId { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        // Foreign Key for Destination
        [Required]
        public int DestinationId { get; set; }
        [ForeignKey("DestinationId")]
        public Destination? Destination { get; set; }

        // Foreign Key for Accommodation
        [Required]
        public int AccommodationId { get; set; }
        [ForeignKey("AccommodationId")]
        public Accommodation? Accommodation { get; set; }

        // Many-to-many for Activities
        public ICollection<Activity>? Activities { get; set; }
    }
}
