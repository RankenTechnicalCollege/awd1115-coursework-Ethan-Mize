﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Trips_Log.Models
{
    public class Activity
    {
        public int ActivityId { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        // Navigation property: many-to-many with Trip
        public ICollection<Trip>? Trips { get; set; }
    }
}
