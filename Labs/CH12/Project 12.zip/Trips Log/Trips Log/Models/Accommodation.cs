﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Trips_Log.Models
{
    public class Accommodation
    {
        public int AccommodationId { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        public string? Phone { get; set; }
        public string? Email { get; set; }

        // Navigation property: one Accommodation → many Trips
        public ICollection<Trip>? Trips { get; set; }
    }
}
