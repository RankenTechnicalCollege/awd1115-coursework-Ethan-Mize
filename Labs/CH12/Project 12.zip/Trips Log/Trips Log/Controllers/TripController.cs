﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Trips_Log.Data;
using Trips_Log.Helpers;
using Trips_Log.Models;
using Trips_Log.ViewModels;

namespace Trips_Log.Controllers
{
    public class TripController : Controller
    {
        private readonly AppDbContext _db;
        private const string Page1Key = "AddTripPage1";
        private const string Page2Key = "AddTripPage2";

        public TripController(AppDbContext db)
        {
            _db = db;
        }

        // Home page: list trips and Add Trip link
        public IActionResult Index()
        {
            // Show any TempData message after saving
            ViewBag.Message = TempData["Message"] as string;

            // Eager load related entities
            var trips = _db.Trips
                .Include(t => t.Destination)
                .Include(t => t.Accommodation)
                .Include(t => t.Activities)
                .OrderByDescending(t => t.TripId)
                .ToList();

            return View(trips);
        }

        // ---------- Page 1 ----------
        [HttpGet]
        public IActionResult AddPage1()
        {
            var vm = TempData.Get<AddTripPage1ViewModel>(Page1Key) ?? new AddTripPage1ViewModel();

            // populate dropdown for destinations
            ViewBag.Destinations = new SelectList(_db.Destinations, "DestinationId", "Name");

            // subhead not needed on first page
            ViewBag.SubHeader = string.Empty;

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage1(AddTripPage1ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Destinations = new SelectList(_db.Destinations, "DestinationId", "Name");
                return View(model);
            }

            TempData.Put(Page1Key, model);
            return RedirectToAction(nameof(AddPage2));
        }

        // ---------- Page 2 ----------
        [HttpGet]
        public IActionResult AddPage2()
        {
            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            if (page1 != null) TempData.Put(Page1Key, page1);

            var vm = TempData.Get<AddTripPage2ViewModel>(Page2Key) ?? new AddTripPage2ViewModel();

            // populate accommodations dropdown
            ViewBag.Accommodations = new SelectList(_db.Accommodations, "AccommodationId", "Name");

            // subheader = selected destination name
            if (page1 != null)
            {
                var destination = _db.Destinations.Find(page1.DestinationId);
                ViewBag.SubHeader = destination?.Name ?? string.Empty;
            }

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage2(AddTripPage2ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Accommodations = new SelectList(_db.Accommodations, "AccommodationId", "Name");
                var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
                if (page1 != null) TempData.Put(Page1Key, page1);

                var destination = _db.Destinations.Find(page1?.DestinationId);
                ViewBag.SubHeader = destination?.Name ?? string.Empty;
                return View(model);
            }

            TempData.Put(Page2Key, model);
            return RedirectToAction(nameof(AddPage3));
        }

        // ---------- Page 3 ----------
        [HttpGet]
        public IActionResult AddPage3()
        {
            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            if (page1 != null) TempData.Put(Page1Key, page1);

            var page2 = TempData.Get<AddTripPage2ViewModel>(Page2Key);
            if (page2 != null) TempData.Put(Page2Key, page2);

            var vm = TempData.Get<AddTripPage3ViewModel>("AddTripPage3") ?? new AddTripPage3ViewModel();

            // load activities list
            ViewBag.Activities = new MultiSelectList(_db.Activities, "ActivityId", "Name");

            var destination = _db.Destinations.Find(page1?.DestinationId);
            ViewBag.SubHeader = destination?.Name ?? string.Empty;

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage3(AddTripPage3ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            var page2 = TempData.Get<AddTripPage2ViewModel>(Page2Key);

            if (page1 == null || page2 == null)
            {
                ModelState.AddModelError("", "Trip information missing. Start again.");
                return RedirectToAction(nameof(AddPage1));
            }

            var trip = new Trip
            {
                StartDate = page1.StartDate!.Value,
                EndDate = page1.EndDate!.Value,
                DestinationId = page1.DestinationId,
                AccommodationId = page2.AccommodationId
            };

            if (model.SelectedActivityIds != null && model.SelectedActivityIds.Any())
            {
                trip.Activities = _db.Activities
                    .Where(a => model.SelectedActivityIds.Contains(a.ActivityId))
                    .ToList();
            }

            _db.Trips.Add(trip);
            _db.SaveChanges();

            TempData.Clear();
            TempData["Message"] = "Trip added successfully.";
            return RedirectToAction(nameof(Index));
        }
    }
}