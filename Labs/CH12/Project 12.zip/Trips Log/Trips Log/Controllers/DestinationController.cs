﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Trips_Log.Data;
using Trips_Log.Models;

namespace Trips_Log.Controllers
{
    public class DestinationController : Controller
    {
        private readonly AppDbContext _db;
        public DestinationController(AppDbContext db) => _db = db;

        public IActionResult Index()
        {
            var destinations = _db.Destinations.OrderBy(d => d.Name).ToList();
            return View(destinations);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Destination dest)
        {
            if (!ModelState.IsValid) return View(dest);
            _db.Destinations.Add(dest);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var dest = _db.Destinations.Include(d => d.Trips).FirstOrDefault(d => d.DestinationId == id);
            if (dest == null) return NotFound();
            if (dest.Trips.Any())
            {
                TempData["Error"] = "Cannot delete destination linked to trips.";
                return RedirectToAction(nameof(Index));
            }
            _db.Destinations.Remove(dest);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
