﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Trips_Log.Data;
using Trips_Log.Models;

namespace Trips_Log.Controllers
{
    public class AccommodationController : Controller
    {
        private readonly AppDbContext _db;
        public AccommodationController(AppDbContext db) => _db = db;

        // List all accommodations
        public IActionResult Index()
        {
            var accommodations = _db.Accommodations
                                    .Include(a => a.Trips)
                                    .OrderBy(a => a.Name)
                                    .ToList();
            return View(accommodations);
        }

        // Show add form
        [HttpGet]
        public IActionResult Create() => View();

        // Handle add form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Accommodation acc)
        {
            if (!ModelState.IsValid) return View(acc);
            _db.Accommodations.Add(acc);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // Delete
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var acc = _db.Accommodations.Include(a => a.Trips).FirstOrDefault(a => a.AccommodationId == id);
            if (acc == null) return NotFound();
            if (acc.Trips.Any())
            {
                TempData["Error"] = "Cannot delete accommodation linked to trips.";
                return RedirectToAction(nameof(Index));
            }

            _db.Accommodations.Remove(acc);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
