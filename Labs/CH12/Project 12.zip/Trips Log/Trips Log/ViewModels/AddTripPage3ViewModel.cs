﻿namespace Trips_Log.ViewModels
{
    public class AddTripPage3ViewModel
    {
        public List<int>? SelectedActivityIds { get; set; }  // multi-select values
    }
}
