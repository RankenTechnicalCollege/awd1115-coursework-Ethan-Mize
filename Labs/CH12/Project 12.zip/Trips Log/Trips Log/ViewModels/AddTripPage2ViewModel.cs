﻿using System.ComponentModel.DataAnnotations;

namespace Trips_Log.ViewModels
{
    public class AddTripPage2ViewModel
    {
        [Required]
        public int AccommodationId { get; set; }
    }
}
