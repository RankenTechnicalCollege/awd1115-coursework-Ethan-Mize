﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Trips_Log.ViewModels
{
    public class AddTripPage1ViewModel
    {
        [Required]
        public int DestinationId { get; set; }

        [Required]
        public DateTime? StartDate { get; set; }

        [Required]
        public DateTime? EndDate { get; set; }
    }
}
