using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Trips_Log.Views.Activity
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
