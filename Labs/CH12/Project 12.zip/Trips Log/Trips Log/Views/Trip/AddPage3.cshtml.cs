using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Trips_Log.Views.Trips
{
    public class AddPage3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
