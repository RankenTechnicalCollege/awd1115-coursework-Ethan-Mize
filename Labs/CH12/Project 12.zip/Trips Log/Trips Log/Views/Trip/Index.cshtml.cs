using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Trips_Log.Views.Trips
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
