using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Trips_Log.Views.Destination
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
