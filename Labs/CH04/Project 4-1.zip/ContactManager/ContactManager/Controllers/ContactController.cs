﻿using ContactManager.Data;
using ContactManager.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;

namespace ContactManager.Controllers
{
    public class ContactController : Controller
    {
        private readonly AppDBContext _db;
        public ContactController(AppDBContext db) => _db = db;

        // Index
        public async Task<IActionResult> List()
        {
            var contacts = await _db.Contacts.Include(c => c.Category).ToListAsync();
            return View(contacts);
        }

        // Details: we accept optional slug
        public async Task<IActionResult> Details(int id)
        {
            var contact = await _db.Contacts.Include(c => c.Category)
                .FirstOrDefaultAsync(c => c.Id == id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        // GET Create (Add)
        public IActionResult Create()
        {
            PopulateCategoriesDropDown();
            ViewBag.ActionName = "Create";  // tell view which action to post to
            ViewBag.Title = "Add Contact";  // dynamic title
            ViewBag.SubmitButtonText = "Add Contact";
            ViewBag.CancelAction = "List";
            return View("Add", new Contact());
        }

        // POST Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Contact contact, string? submit)
        {
            // Cancel button handling
            if (!string.IsNullOrEmpty(submit) && submit == "cancel")
            {
                return RedirectToAction("Index");
            }

            if (ModelState.IsValid)
            {
                contact.DateAdded = DateTime.UtcNow; // set server-side only
                _db.Contacts.Add(contact);
                await _db.SaveChangesAsync();
                return RedirectToAction("Details", new { id = contact.Id, slug = contact.Slug });
            }

            PopulateCategoriesDropDown(contact.CategoryId);
            return View("Form", contact);
        }

        // GET Edit
        public async Task<IActionResult> Edit(int id)
        {
            var contact = await _db.Contacts.FindAsync(id);
            if (contact == null) return NotFound();

            PopulateCategoriesDropDown(contact.CategoryId);
            ViewBag.ActionName = "Edit";      // post to Edit
            ViewBag.Title = "Edit Contact";   // dynamic title
            ViewBag.SubmitButtonText = "Update Contact";
            ViewBag.CancelAction = "Details";       // cancel goes to Details page
            return View("Add", contact);      // reuse Add.cshtml
        }

        // POST Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Contact contact, string? submit)
        {
            if (!string.IsNullOrEmpty(submit) && submit == "cancel")
            {
                // Redirect back to Details page for this contact
                return RedirectToAction("Details", new { id = id, slug = contact.Slug });
            }

            if (id != contact.Id) return BadRequest();

            if (ModelState.IsValid)
            {
                // Only update editable fields (keep DateAdded unchanged)
                var dbContact = await _db.Contacts.FindAsync(id);
                if (dbContact == null) return NotFound();

                dbContact.Firstname = contact.Firstname;
                dbContact.Lastname = contact.Lastname;
                dbContact.Phone = contact.Phone;
                dbContact.Email = contact.Email;
                dbContact.CategoryId = contact.CategoryId;

                await _db.SaveChangesAsync();
                return RedirectToAction("Details", new { id = dbContact.Id, slug = dbContact.Slug });
            }

            PopulateCategoriesDropDown(contact.CategoryId);
            return View("Form", contact);
        }

        // GET: /Contact/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var contact = await _db.Contacts
                .Include(c => c.Category)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (contact == null) return NotFound();

            return View(contact); // Shows a confirmation page
        }

        // POST: /Contact/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var contact = await _db.Contacts.FindAsync(id);
            if (contact == null) return NotFound();

            _db.Contacts.Remove(contact);
            await _db.SaveChangesAsync();

            return RedirectToAction("List"); // Go back to the list page
        }

        private void PopulateCategoriesDropDown(object? selected = null)
        {
            ViewBag.CategoryList = new SelectList(_db.Categories.OrderBy(c => c.Name), "Id", "Name", selected);
        }
    }
}
