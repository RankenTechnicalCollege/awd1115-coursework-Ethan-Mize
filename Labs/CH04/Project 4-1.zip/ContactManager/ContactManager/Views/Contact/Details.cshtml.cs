using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContactManager.Views.Contact
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
