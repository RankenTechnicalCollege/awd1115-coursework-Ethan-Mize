using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContactManager.Views.Contact
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
