using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContactManager.Views.Contact
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
