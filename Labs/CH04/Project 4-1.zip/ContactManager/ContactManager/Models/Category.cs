﻿using System.ComponentModel.DataAnnotations;
namespace ContactManager.Models
{
    public class Category
    {
        // PK - by convention EF will make this DB-generated identity
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = "";

        // Navigation (optional)
        public ICollection<Contact>? Contacts { get; set; }
    }
}
