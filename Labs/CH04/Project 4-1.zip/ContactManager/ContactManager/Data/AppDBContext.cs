﻿using ContactManager.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace ContactManager.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> opts) : base(opts) { }

        public DbSet<Contact> Contacts { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Seed categories
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Friend" },
                new Category { Id = 2, Name = "Family" },
                new Category { Id = 3, Name = "Work" }
            );

            // Seed a sample contact (DateAdded must be explicit)
            // Seed 5 contacts
            // Configure default value for DateAdded to use database function
            modelBuilder.Entity<Contact>()
                .Property(c => c.DateAdded)
                .HasDefaultValueSql("GETUTCDATE()"); // For SQL Server, use "datetime('now')" for SQLite

            // Seed 5 contacts without DateAdded - will use default value
            modelBuilder.Entity<Contact>().HasData(
                new Contact
                {
                    Id = 1,
                    Firstname = "Alice",
                    Lastname = "Johnson",
                    Phone = "111-222-3333",
                    Email = "alice@example.com",
                    CategoryId = 1
                },
                new Contact
                {
                    Id = 2,
                    Firstname = "Bob",
                    Lastname = "Smith",
                    Phone = "222-333-4444",
                    Email = "bob@example.com",
                    CategoryId = 2
                },
                new Contact
                {
                    Id = 3,
                    Firstname = "Charlie",
                    Lastname = "Brown",
                    Phone = "333-444-5555",
                    Email = "charlie@example.com",
                    CategoryId = 1
                },
                new Contact
                {
                    Id = 4,
                    Firstname = "Diana",
                    Lastname = "Miller",
                    Phone = "444-555-6666",
                    Email = "diana@example.com",
                    CategoryId = 1
                },
                new Contact
                {
                    Id = 5,
                    Firstname = "Ethan",
                    Lastname = "Williams",
                    Phone = "555-666-7777",
                    Email = "ethan@example.com",
                    CategoryId = 3
                }
            );
        }
    }
}
