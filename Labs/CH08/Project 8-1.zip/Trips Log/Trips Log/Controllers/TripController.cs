﻿using Microsoft.AspNetCore.Mvc;
using Trips_Log.Data;
using Trips_Log.Helpers;
using Trips_Log.Models;
using Trips_Log.ViewModels;

namespace Trips_Log.Controllers
{
    public class TripController : Controller
    {
        private readonly AppDbContext _db;
        private const string Page1Key = "AddTripPage1";
        private const string Page2Key = "AddTripPage2";

        public TripController(AppDbContext db)
        {
            _db = db;
        }

        // Home page: list trips and Add Trip link
        public IActionResult Index()
        {
            // Show any TempData message after saving
            ViewBag.Message = TempData["Message"] as string;
            var trips = _db.Trips.OrderByDescending(t => t.TripId).ToList();
            return View(trips);
        }

        // ---------- Page 1 ----------
        [HttpGet]
        public IActionResult AddPage1()
        {
            // prefill from TempData if present
            var vm = TempData.Get<AddTripPage1ViewModel>(Page1Key) ?? new AddTripPage1ViewModel();
            // If we want accommodation in layout subhead later, set ViewBag here if present
            ViewBag.SubHeader = vm.Accommodation ?? string.Empty;
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage1(AddTripPage1ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            if (!ModelState.IsValid)
            {
                // keep subheader from any partial data
                ViewBag.SubHeader = model.Accommodation ?? string.Empty;
                return View(model);
            }

            // store page1 model in TempData
            TempData.Put(Page1Key, model);

            // redirect to page 2
            return RedirectToAction(nameof(AddPage2));
        }

        // ---------- Page 2 ----------
        [HttpGet]
        public IActionResult AddPage2()
        {
            // load page1 from TempData to display subhead
            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            // retrieve without removing? Our helper reads value but TempData normally clears value on read.
            // To keep it for next reads, we re-add it back into TempData
            if (page1 != null) TempData.Put(Page1Key, page1);

            var vm = TempData.Get<AddTripPage2ViewModel>(Page2Key) ?? new AddTripPage2ViewModel
            {
                Accommodation = page1?.Accommodation
            };

            ViewBag.SubHeader = page1?.Accommodation ?? string.Empty;
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage2(AddTripPage2ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            // page2 fields are optional; no ModelState validation required, but if you had [EmailAddress] it will validate
            if (!ModelState.IsValid)
            {
                // keep subheader visible from stored page1
                var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
                if (page1 != null) TempData.Put(Page1Key, page1);
                ViewBag.SubHeader = page1?.Accommodation ?? string.Empty;
                return View(model);
            }

            // store page2 in TempData
            TempData.Put(Page2Key, model);

            return RedirectToAction(nameof(AddPage3));
        }

        // ---------- Page 3 ----------
        [HttpGet]
        public IActionResult AddPage3()
        {
            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            if (page1 != null) TempData.Put(Page1Key, page1);

            var page2 = TempData.Get<AddTripPage2ViewModel>(Page2Key);
            if (page2 != null) TempData.Put(Page2Key, page2);

            var vm = TempData.Get<AddTripPage3ViewModel>("AddTripPage3") ?? new AddTripPage3ViewModel
            {
                Destination = page1?.Destination
            };

            ViewBag.SubHeader = page1?.Destination ?? string.Empty;
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddPage3(AddTripPage3ViewModel model, string action)
        {
            if (action == "Cancel")
            {
                TempData.Clear();
                return RedirectToAction(nameof(Index));
            }

            // Save: combine page1, page2, page3 into Trip and persist
            var page1 = TempData.Get<AddTripPage1ViewModel>(Page1Key);
            var page2 = TempData.Get<AddTripPage2ViewModel>(Page2Key);

            if (page1 == null)
            {
                // something went wrong, return to page1
                ModelState.AddModelError("", "Trip information missing. Start again.");
                return RedirectToAction(nameof(AddPage1));
            }

            var trip = new Trip
            {
                Destination = page1.Destination,
                Accommodation = page1.Accommodation,
                StartDate = page1.StartDate!.Value,
                EndDate = page1.EndDate!.Value,
                AccommodationPhone = page2?.PhoneNumber,
                AccommodationEmail = page2?.EmailAddress,
                Activity1 = model.Activity1,
                Activity2 = model.Activity2,
                Activity3 = model.Activity3
            };

            _db.Trips.Add(trip);
            _db.SaveChanges();

            // clear wizard data
            TempData.Clear();

            // show temporary message on home
            TempData["Message"] = $"Trip to {trip.Destination} added.";

            return RedirectToAction(nameof(Index));
        }
    }
}
