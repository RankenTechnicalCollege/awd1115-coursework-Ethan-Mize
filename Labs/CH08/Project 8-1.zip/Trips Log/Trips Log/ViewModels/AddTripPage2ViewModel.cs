﻿using System.ComponentModel.DataAnnotations;

namespace Trips_Log.ViewModels
{
    public class AddTripPage2ViewModel
    {
        // accommodation displayed on subhead only; not required here
        public string? Accommodation { get; set; }

        // optional phone/email -> use nullable string
        public string? PhoneNumber { get; set; }
        [EmailAddress]
        public string? EmailAddress { get; set; }
    }
}
