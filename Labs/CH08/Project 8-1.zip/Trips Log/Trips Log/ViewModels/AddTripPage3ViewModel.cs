﻿namespace Trips_Log.ViewModels
{
    public class AddTripPage3ViewModel
    {
        // destination used in subhead only
        public string? Destination { get; set; }

        // optional activities
        public string? Activity1 { get; set; }
        public string? Activity2 { get; set; }
        public string? Activity3 { get; set; }
    }
}
