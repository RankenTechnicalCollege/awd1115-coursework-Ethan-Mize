﻿using Microsoft.EntityFrameworkCore;
using Trips_Log.Models;

namespace Trips_Log.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<Trip> Trips { get; set; } = null!;
    }
}
