﻿namespace LMS.Models
{
    public class Author
    {
        public int AuthorID { get; set; }
        public string AuthorName { get; set; }

        // One author -> many books
        public ICollection<Book> Books { get; set; }
    }
}
