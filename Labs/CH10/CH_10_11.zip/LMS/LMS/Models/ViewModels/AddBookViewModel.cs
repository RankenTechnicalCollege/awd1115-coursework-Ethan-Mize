﻿using System.ComponentModel.DataAnnotations;

namespace LMS.Models.ViewModels
{
    public class AddBookViewModel
    {
        [Required, MaxLength(200)]
        public string Title { get; set; }

        [Required, MaxLength(100)]
        public string AuthorName { get; set; }

        [Required, MaxLength(50)]
        public string ISBN { get; set; }
    }
}
