﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LMS.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; }

        [Required, MaxLength(50)]
        public string ISBN { get; set; }

        // Foreign key to Author
        [Display(Name = "Author")]
        public int AuthorID { get; set; }

        // Navigation property (should be of type Author)
        [ForeignKey("AuthorID")]
        public Author Author { get; set; }
    }
}
