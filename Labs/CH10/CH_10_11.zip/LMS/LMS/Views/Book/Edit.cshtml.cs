using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Views.Book
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
