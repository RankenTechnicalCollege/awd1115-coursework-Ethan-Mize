﻿using LMS.Data;
using LMS.Models;
using LMS.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace LMS.Controllers
{
    [Route("books")]
    public class BookController : Controller
    {
        private readonly AppDBContext _context;
      
        public BookController(AppDBContext context)
        {
            _context = context;
        }

        // GET: Books
        [HttpGet("")]
        public async Task<IActionResult> List(string searchQuery, int page = 1)
        {
            int pageSize = 3; // ✅ 3 books per page

            // Base query
            var query = _context.Books
                .Include(b => b.Author)
                .AsQueryable();

            // ✅ Apply search filter if searchQuery is provided
            if (!string.IsNullOrEmpty(searchQuery))
            {
                searchQuery = searchQuery.ToLower();
                query = query.Where(b =>
                    b.Title.ToLower().Contains(searchQuery) ||
                    b.ISBN.ToLower().Contains(searchQuery) ||
                    (b.Author != null && b.Author.AuthorName.ToLower().Contains(searchQuery))
                );
            }

            // ✅ Count total results (for pagination)
            var totalBooks = await query.CountAsync();

            // ✅ Apply pagination
            var books = await query
                .OrderBy(b => b.BookID)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // ✅ Send pagination + search info to view
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalBooks / pageSize);
            ViewBag.SearchQuery = searchQuery;

            return View(books);
        }

        // GET: Books/add
        [HttpGet("add/")]
        public IActionResult Add()
        {
            return View();
        }

        // POST: Books/Create
        [HttpPost("add/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(AddBookViewModel model)
        {
            if (ModelState.IsValid)
            {
                // 🔍 Check if author already exists (case-insensitive)
                var existingAuthor = await _context.Authors
                    .FirstOrDefaultAsync(a => a.AuthorName.ToLower() == model.AuthorName.ToLower());

                Author author;
                if (existingAuthor == null)
                {
                    // ✳️ Add new author
                    author = new Author { AuthorName = model.AuthorName };
                    _context.Authors.Add(author);
                    await _context.SaveChangesAsync(); // ensures AuthorID is generated
                }
                else
                {
                    author = existingAuthor;
                }

                // 🆕 Create new book linked to that author
                var newBook = new Book
                {
                    Title = model.Title,
                    ISBN = model.ISBN,
                    AuthorID = author.AuthorID
                };

                _context.Books.Add(newBook);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Book added successfully!";
                return RedirectToAction(nameof(List));
            }

            return View(model);
        }

        // DELETE => /books/delete/{id}/{slug}/
        [HttpGet("delete/{id:int}/{slug}/")]
        public async Task<IActionResult> Delete(int id, string slug)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookID == id);
            if (book == null) return NotFound();

            return View(book);
        }

        [HttpPost("delete/{id:int}/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book != null)
            {
                _context.Books.Remove(book);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Book deleted successfully!";
            }
            return RedirectToAction(nameof(List));
        }

        // EDIT => /books/edit/{id}/{slug}/
        [HttpGet("edit/{id:int}/{slug}/")]
        public async Task<IActionResult> Edit(int id, string slug)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            return View(book);
        }

        [HttpPost("edit/{id:int}/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Book book)
        {
            if (id != book.BookID) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(book);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Book updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.BookID)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(List));
            }
            return View(book);
        }


        // DETAILS => /books/{id}/{slug}/
        [HttpGet("{id:int}/{slug}/")]
        public async Task<IActionResult> Details(int id, string slug)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookID == id);
            if (book == null) return NotFound();

            // Ensure slug matches title, else redirect
            var expectedSlug = ToSlug(book.Title);
            if (slug != expectedSlug)
                return RedirectToAction(nameof(Details), new { id, slug = expectedSlug });

            return View(book);
        }

        // Helper method to check if book exists
        private bool BookExists(int id)
        {
            return _context.Books.Any(b => b.BookID == id);
        }
        private string ToSlug(string title)
        {
            if (string.IsNullOrEmpty(title)) return "";
            return title
                .ToLower()
                .Replace(" ", "-")
                .Replace(".", "")
                .Replace(",", "")
                .Replace(":", "")
                .Replace(";", "")
                .Replace("!", "")
                .Replace("?", "");
        }
    }
}
