using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Areas.Admin.Views.Dashboard
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
