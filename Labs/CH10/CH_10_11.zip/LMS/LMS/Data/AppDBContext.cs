﻿using LMS.Models;
using Microsoft.EntityFrameworkCore;

namespace LMS.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }  // Add this line

        public DbSet<Author> Authors { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed 5 books
            modelBuilder.Entity<Book>().HasData(
                new Book { BookID = 1, Title = "The Great Gatsby", ISBN = "9780743273565", AuthorID = 1 },
                new Book { BookID = 2, Title = "To Kill a Mockingbird", ISBN = "9780061120084", AuthorID = 2 },
                new Book { BookID = 3, Title = "1984", ISBN = "9780451524935", AuthorID = 3 },
                new Book { BookID = 4, Title = "Pride and Prejudice", ISBN = "9781503290563", AuthorID = 4 },
                new Book { BookID = 5, Title = "The Catcher in the Rye", ISBN = "9780316769488", AuthorID = 5 }
            );

            // Seed Authors
            modelBuilder.Entity<Author>().HasData(
                new Author { AuthorID = 1, AuthorName = "F. Scott Fitzgerald" },
                new Author { AuthorID = 2, AuthorName = "Harper Lee" },
                new Author { AuthorID = 3, AuthorName = "George Orwell" },
                new Author { AuthorID = 4, AuthorName = "Jane Austen" },
                new Author { AuthorID = 5, AuthorName = "J.D. Salinger" }
            );
        }
    }
}
