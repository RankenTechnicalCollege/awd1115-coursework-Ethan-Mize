using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using myWebsiteApp.Models;

namespace myWebsiteApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            var contacts = new List<string>
            {
                "Email: info@mysite.com",
                "Phone: (555) 123-4567",
                "Address: 123 Main St, City"
            };

            return View(contacts);
        }
    }
}
