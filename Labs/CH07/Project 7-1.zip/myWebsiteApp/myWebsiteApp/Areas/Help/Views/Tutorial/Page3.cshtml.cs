using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myWebsiteApp.Areas.Help.Views.Tutorial
{
    public class Page3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
