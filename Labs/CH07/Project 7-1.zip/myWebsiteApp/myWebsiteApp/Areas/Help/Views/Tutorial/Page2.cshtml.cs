using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myWebsiteApp.Areas.Help.Views.Tutorial
{
    public class Page2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
