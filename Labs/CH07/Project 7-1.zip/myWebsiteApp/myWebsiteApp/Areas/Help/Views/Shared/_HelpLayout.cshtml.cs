using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myWebsiteApp.Areas.Help.Views.Shared
{
    public class _HelpLayoutModel : PageModel
    {
        public void OnGet() { }
    }
}
