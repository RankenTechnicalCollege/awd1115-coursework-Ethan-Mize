using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myWebsiteApp.Areas.Help.Views
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
