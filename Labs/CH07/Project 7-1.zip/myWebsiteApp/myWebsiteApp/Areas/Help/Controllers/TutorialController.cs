﻿using Microsoft.AspNetCore.Mvc;

namespace myWebsiteApp.Areas.Help.Controllers
{
    [Area("Help")]
    [Route("Help/[controller]")]
    public class TutorialController : Controller
    {
        [Route("page-1")]
        public IActionResult Page1()
        {
            return View("Page1");
        }
        [Route("page-2")]
        public IActionResult Page2()
        {
            return View("Page2");
        }
        [Route("page-3")]
        public IActionResult Page3()
        {
            return View("Page3");
        }

        // Optional: If someone just visits /Help/Tutorial, go to Page1
        public IActionResult Index()
        {
            return RedirectToAction("Page1");
        }
    }
}
