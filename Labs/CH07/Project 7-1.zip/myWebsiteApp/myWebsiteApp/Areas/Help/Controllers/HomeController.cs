﻿using Microsoft.AspNetCore.Mvc;
namespace myWebsiteApp.Areas.Help.Controllers
{
    [Area("Help")]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
