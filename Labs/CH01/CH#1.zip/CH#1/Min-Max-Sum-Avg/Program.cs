﻿int num1, num2;
bool isValid;

// Get first number
do
{
    Console.Write("Enter first number: ");
    isValid = int.TryParse(Console.ReadLine(), out num1);
    if (!isValid)
        Console.WriteLine("Invalid input! Please enter a valid integer.");
}
while (!isValid);

// Get second number
do
{
    Console.Write("Enter second number: ");
    isValid = int.TryParse(Console.ReadLine(), out num2);
    if (!isValid)
        Console.WriteLine("Invalid input! Please enter a valid integer.");
}
while (!isValid);

int sum = num1 + num2;
double avg = (num1 + num2) / 2.0;
int max = Math.Max(num1, num2);
int min = Math.Min(num1, num2);

Console.WriteLine("\nResults:");
Console.WriteLine($"Sum: {sum}");
Console.WriteLine($"Average: {avg}");
Console.WriteLine($"Maximum: {max}");
Console.WriteLine($"Minimum: {min}");
