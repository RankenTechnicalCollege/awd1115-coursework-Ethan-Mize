﻿Console.WriteLine("Please Enter your name:");
string name = Console.ReadLine();
Console.WriteLine("Please Enter your age:");
string age = Console.ReadLine();
Console.WriteLine($"Hi {name}! You are {age} years old");

