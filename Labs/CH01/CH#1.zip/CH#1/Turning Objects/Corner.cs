﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turning_Objects
{
    public class Corner : ITurnable
    {
        public void Turn()
        {
            Console.WriteLine("You turn around the street corner.");
        }
    }
}
