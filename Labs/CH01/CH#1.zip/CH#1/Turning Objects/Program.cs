﻿// Create a list of ITurnable
using Turning_Objects;

List<ITurnable> turnables = new List<ITurnable>
        {
            new Page(),
            new Corner(),
            new Pancake(),
            new Leaf()
        };

// Call the method to perform turns
MakeThemTurn(turnables);

    static void MakeThemTurn(List<ITurnable> items)
{
    foreach (var item in items)
    {
        item.Turn();
    }
}