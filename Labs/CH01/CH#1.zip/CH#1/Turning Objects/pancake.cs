﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turning_Objects
{
    public class Pancake : ITurnable
    {
        public void Turn()
        {
            Console.WriteLine("You flip the pancake on the pan.");
        }
    }
}
