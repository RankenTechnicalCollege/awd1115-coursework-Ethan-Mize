﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turning_Objects
{
    public interface ITurnable
    {
        void Turn();
    }

}
