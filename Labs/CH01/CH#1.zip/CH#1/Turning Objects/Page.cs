﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turning_Objects
{
    public class Page : ITurnable
    {
        public void Turn()
        {
            Console.WriteLine("You turn the page to continue reading the book.");
        }
    }
}
