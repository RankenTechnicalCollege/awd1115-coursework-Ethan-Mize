﻿Dictionary<string, string> contacts = new Dictionary<string, string>();
bool running = true;

while (running)
{
    Console.WriteLine("\n==== Contact Manager ====");
    Console.WriteLine("1. Add Contact");
    Console.WriteLine("2. View Contact");
    Console.WriteLine("3. Update Contact");
    Console.WriteLine("4. Delete Contact");
    Console.WriteLine("5. List All Contacts");
    Console.WriteLine("6. Exit");
    Console.Write("Choose an option (1-6): ");

    string choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1":
            Console.Write("Enter contact name: ");
            string name = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Invalid name. Try again.");
                break;
            }

            if (contacts.ContainsKey(name))
            {
                Console.WriteLine("Contact already exists!");
            }
            else
            {
                Console.Write("Enter phone number: ");
                string phone = Console.ReadLine();
                contacts[name] = phone;
                Console.WriteLine("Contact added successfully!");
            }
            break;

        case "2":
            Console.Write("Enter contact name to view: ");
            string viewName = Console.ReadLine();
            if (contacts.TryGetValue(viewName, out string foundPhone))
            {
                Console.WriteLine($"Contact: {viewName} - Phone: {foundPhone}");
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
            break;

        case "3":
            Console.Write("Enter contact name to update: ");
            string updateName = Console.ReadLine();
            if (contacts.ContainsKey(updateName))
            {
                Console.Write("Enter new phone number: ");
                string newPhone = Console.ReadLine();
                contacts[updateName] = newPhone;
                Console.WriteLine("Contact updated successfully!");
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
            break;

        case "4":
            Console.Write("Enter contact name to delete: ");
            string deleteName = Console.ReadLine();
            if (contacts.Remove(deleteName))
            {
                Console.WriteLine("Contact deleted successfully!");
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
            break;

        case "5":
            Console.WriteLine("All Contacts:");
            if (contacts.Count == 0)
            {
                Console.WriteLine("No contacts available.");
            }
            else
            {
                foreach (var contact in contacts)
                {
                    Console.WriteLine($"- {contact.Key}: {contact.Value}");
                }
            }
            break;

        case "6":
            running = false;
            Console.WriteLine("Exiting... Goodbye!");
            break;

        default:
            Console.WriteLine("Invalid option! Please enter a number between 1 and 6.");
            break;
    }
}