﻿using Shopping_Cart;
Cart myCart = new Cart("CART001");

myCart.AddItem("Lollipop", 2.5);
myCart.AddItem("Chocolate", 5.0);
myCart.AddItem("Juice", 3.75);

myCart.ListItems();

myCart.RemoveItem("Chocolate");

myCart.ListItems();
