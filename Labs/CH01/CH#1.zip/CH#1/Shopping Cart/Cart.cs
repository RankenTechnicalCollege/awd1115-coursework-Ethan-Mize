﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping_Cart
{
    internal class Cart
    {
        private string _CartId;
        private Dictionary<string, double> _Items;

        // Constructor
        public Cart(string cartId)
        {
            _CartId = cartId;
            _Items = new Dictionary<string, double>();
        }

        // Add item to the cart
        public void AddItem(string itemName, double price)
        {
            if (string.IsNullOrWhiteSpace(itemName) || price < 0)
            {
                Console.WriteLine("Invalid item or price.");
                return;
            }

            _Items[itemName] = price; // overwrite if item already exists
            Console.WriteLine($"Added '{itemName}' with price {price:C} to cart.");
        }

        // Remove item from the cart
        public void RemoveItem(string itemName)
        {
            if (_Items.Remove(itemName))
            {
                Console.WriteLine($"Removed '{itemName}' from cart.");
            }
            else
            {
                Console.WriteLine($"Item '{itemName}' not found in cart.");
            }
        }

        // Get total cost of items
        public double GetTotal()
        {
            double total = 0;
            foreach (var item in _Items.Values)
            {
                total += item;
            }
            return total;
        }

        // List all items
        public void ListItems()
        {
            Console.WriteLine($"\nCart ID: {_CartId}");
            if (_Items.Count == 0)
            {
                Console.WriteLine("Cart is empty.");
            }
            else
            {
                foreach (var item in _Items)
                {
                    Console.WriteLine($"- {item.Key}: {item.Value:C}");
                }
                Console.WriteLine($"Total: {GetTotal():C}");
            }
        }
    }
}
