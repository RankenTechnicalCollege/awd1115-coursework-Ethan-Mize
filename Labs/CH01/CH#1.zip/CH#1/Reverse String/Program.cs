﻿string input;
bool isValid;

// Keep asking until user enters a valid non-empty string
do
{
    Console.Write("Enter a string: ");
    input = Console.ReadLine();

    isValid = !string.IsNullOrWhiteSpace(input);

    if (!isValid)
        Console.WriteLine("Invalid input! Please enter a non-empty string.");
}
while (!isValid);

// Reverse the string
char[] charArray = input.ToCharArray();
Array.Reverse(charArray);
string reversed = new string(charArray);

Console.WriteLine("\nReversed string: " + reversed);