﻿int rows, cols;
bool isValid;

// Get number of rows
do
{
    Console.Write("Enter number of rows: ");
    string input = Console.ReadLine();
    isValid = int.TryParse(input, out rows) && rows > 0;

    if (!isValid)
        Console.WriteLine("Invalid input! Please enter a positive integer.");
}
while (!isValid);

// Get number of columns
do
{
    Console.Write("Enter number of columns: ");
    string input = Console.ReadLine();
    isValid = int.TryParse(input, out cols) && cols > 0;

    if (!isValid)
        Console.WriteLine("Invalid input! Please enter a positive integer.");
}
while (!isValid);

// Print multiplication table
Console.WriteLine("\nTable Output:\n");

for (int i = 1; i <= rows; i++)
{
    for (int j = 1; j <= cols; j++)
    {
        Console.Write((i * j).ToString().PadLeft(4));
    }
    Console.WriteLine();
}