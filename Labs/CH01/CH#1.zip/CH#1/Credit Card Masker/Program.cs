﻿Console.Write("Enter credit card number: ");
string input = Console.ReadLine();

if (string.IsNullOrWhiteSpace(input))
{
    Console.WriteLine("Invalid input! Please enter a non-empty card number.");
    return;
}

// Count how many letter/digit characters are in the string
int totalLettersDigits = 0;
foreach (char c in input)
{
    if (char.IsDigit(c) || char.IsLetter(c))
        totalLettersDigits++;
}

// We want to leave last 4 digits/letters as-is
int lettersDigitsToMask = Math.Max(0, totalLettersDigits - 4);
int maskedCount = 0;

char[] masked = new char[input.Length];

for (int i = 0; i < input.Length; i++)
{
    char c = input[i];

    if (char.IsDigit(c) || char.IsLetter(c))
    {
        if (maskedCount < lettersDigitsToMask)
        {
            masked[i] = 'X';
            maskedCount++;
        }
        else
        {
            masked[i] = c; // keep last 4
        }
    }
    else
    {
        masked[i] = c; // keep spaces, dashes, etc.
    }
}

Console.WriteLine("\nMasked Card: " + new string(masked));