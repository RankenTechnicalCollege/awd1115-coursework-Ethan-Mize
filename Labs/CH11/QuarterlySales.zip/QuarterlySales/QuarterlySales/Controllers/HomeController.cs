using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuarterlySales.Data;
using QuarterlySales.Models;
using System.Diagnostics;

namespace QuarterlySales.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? employeeId)
        {
            var employees = await _context.Employees.ToListAsync();
            ViewBag.Employees = employees;

            var sales = _context.Sales.Include(s => s.Employee).AsQueryable();

            if (employeeId.HasValue)
                sales = sales.Where(s => s.EmployeeId == employeeId.Value);

            var salesData = await sales
                .OrderBy(s => s.Year)
                .ThenBy(s => s.Quarter)
                .ToListAsync();

            return View(salesData);
        }
    }
}
