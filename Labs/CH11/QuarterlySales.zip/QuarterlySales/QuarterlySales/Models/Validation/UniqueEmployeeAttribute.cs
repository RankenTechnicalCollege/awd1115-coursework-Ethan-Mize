﻿using System;
using QuarterlySales.Data;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using QuarterlySales.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace QuarterlySales.Models.Validation
{
    public class UniqueEmployeeAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext context)
        {
            // ✅ Ensure the object being validated is actually an Employee
            if (context.ObjectInstance is not Employee employee)
                return ValidationResult.Success;

            var db = context.GetService<AppDbContext>();
            if (db == null) return ValidationResult.Success;

            bool exists = db.Employees.Any(e =>
                e.FirstName == employee.FirstName &&
                e.LastName == employee.LastName &&
                e.DOB == employee.DOB);

            if (exists)
                return new ValidationResult("An employee with this name and date of birth already exists.");

            if (employee.ManagerId != null)
            {
                var manager = db.Employees.Find(employee.ManagerId);
                if (manager != null &&
                    manager.FirstName == employee.FirstName &&
                    manager.LastName == employee.LastName &&
                    manager.DOB == employee.DOB)
                {
                    return new ValidationResult("Employee and manager cannot be the same person.");
                }
            }

            return ValidationResult.Success;
        }
    }
}
