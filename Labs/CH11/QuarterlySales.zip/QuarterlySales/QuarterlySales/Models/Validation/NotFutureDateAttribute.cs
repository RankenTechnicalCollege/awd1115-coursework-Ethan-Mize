﻿using System;
using System.ComponentModel.DataAnnotations;

namespace QuarterlySales.Models.Validation
{
    public class NotFutureDateAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if (value is DateTime date)
                return date <= DateTime.Today;
            return true;
        }
    }
}
