﻿using System;
using QuarterlySales.Data;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;

namespace QuarterlySales.Models.Validation
{
    public class UniqueSalesAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext context)
        {
            // ✅ Make sure we're validating a Sale object
            if (context.ObjectInstance is not Sale sale)
                return ValidationResult.Success;

            var db = context.GetService<AppDbContext>();
            if (db == null) return ValidationResult.Success;

            bool exists = db.Sales.Any(s =>
                s.EmployeeId == sale.EmployeeId &&
                s.Quarter == sale.Quarter &&
                s.Year == sale.Year);

            if (exists)
                return new ValidationResult("Sales record for this quarter and employee already exists.");

            return ValidationResult.Success;
        }
    }
}
