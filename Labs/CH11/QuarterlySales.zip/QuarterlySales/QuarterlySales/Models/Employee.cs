﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using QuarterlySales.Models.Validation;
using System;

namespace QuarterlySales.Models
{
    [UniqueEmployee]
    public class Employee
    {
        public int EmployeeId { get; set; }

        [Required]
        public string FirstName { get; set; } = "";

        [Required]
        public string LastName { get; set; } = "";

        [Required]
        [NotFutureDate]
        public DateTime DOB { get; set; }

        [Required]
        [NotFutureDate]
        [CustomValidation(typeof(Employee), nameof(ValidateHireDate))]
        public DateTime DateOfHire { get; set; }

        public int? ManagerId { get; set; }
        [ForeignKey("ManagerId")]
        public Employee? Manager { get; set; }

        public static ValidationResult? ValidateHireDate(DateTime date, ValidationContext context)
        {
            if (date < new DateTime(1995, 1, 1))
                return new ValidationResult("Hire date cannot be before 1/1/1995.");
            return ValidationResult.Success;
        }

        public string FullName => $"{FirstName} {LastName}";
    }
}
