﻿using System.ComponentModel.DataAnnotations;
using QuarterlySales.Models.Validation;
using System;

namespace QuarterlySales.Models
{
    [UniqueSales]
    public class Sale
    {
        public int SaleId { get; set; }

        [Required, Range(1, 4)]
        public int Quarter { get; set; }

        [Required, Range(2001, 2100)]
        public int Year { get; set; }

        [Required, Range(0.01, double.MaxValue)]
        public decimal Amount { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please select an employee.")]
        public int EmployeeId { get; set; }
        public Employee? Employee { get; set; }
    }
}
