using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace QuarterlySales.Views.Employees
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
