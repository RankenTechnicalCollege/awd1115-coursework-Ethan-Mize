using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace QuarterlySales.Views.Sales
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
