﻿using System.ComponentModel.DataAnnotations;

namespace CarInventoryBackend
{
    public class Car
    {
        [Key]
        public int Id { get; set; } // Mandatory

        [Required]
        public bool IsAvailable { get; set; } // Mandatory

        [Required]
        [StringLength(100)]
        public string? Secret { get; set; } // Mandatory

        [Required]
        [StringLength(50)]
        public string Model { get; set; } // Additional property

        [Range(0, 100000)]
        public decimal PricePerDay { get; set; } // Additional property
    }
}
