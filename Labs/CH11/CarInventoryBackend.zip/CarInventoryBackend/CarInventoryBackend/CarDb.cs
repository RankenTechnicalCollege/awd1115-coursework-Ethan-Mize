﻿using Microsoft.EntityFrameworkCore;

namespace CarInventoryBackend
{
    public class CarDb : DbContext
    {
        public CarDb(DbContextOptions<CarDb> options) 
        : base (options){ }

        public DbSet<Car> Cars {get; set;}
    }
}
