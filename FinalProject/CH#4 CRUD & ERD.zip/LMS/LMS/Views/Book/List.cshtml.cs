using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Views.Books
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
