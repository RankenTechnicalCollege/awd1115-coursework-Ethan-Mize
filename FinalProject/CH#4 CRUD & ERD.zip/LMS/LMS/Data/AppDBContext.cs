﻿using LMS.Models;
using Microsoft.EntityFrameworkCore;

namespace LMS.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }  // Add this line

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed 5 books
            modelBuilder.Entity<Book>().HasData(
                new Book { BookID = 1, Title = "The Great Gatsby", Author = "F. Scott Fitzgerald", ISBN = "9780743273565" },
                new Book { BookID = 2, Title = "To Kill a Mockingbird", Author = "Harper Lee", ISBN = "9780061120084" },
                new Book { BookID = 3, Title = "1984", Author = "George Orwell", ISBN = "9780451524935" },
                new Book { BookID = 4, Title = "Pride and Prejudice", Author = "Jane Austen", ISBN = "9781503290563" },
                new Book { BookID = 5, Title = "The Catcher in the Rye", Author = "J.D. Salinger", ISBN = "9780316769488" }
            );
        }
    }
}
