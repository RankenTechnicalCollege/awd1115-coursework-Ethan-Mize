﻿using System.ComponentModel.DataAnnotations;

namespace LMS.Models
{
    public class BookLend
    {
        [Key]
        public int LendID { get; set; }

        [Required]
        public int BookID { get; set; }
        public Book Book { get; set; }

        [Required]
        public string UserID { get; set; }
        public ApplicationUser User { get; set; }

        [Required]
        public DateTime LendDate { get; set; } = DateTime.Now;

        public DateTime? ReturnDate { get; set; }

        public bool IsReturned => ReturnDate != null;
    }

}
