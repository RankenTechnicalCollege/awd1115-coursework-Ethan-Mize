﻿// Path: Models/ViewModels/UserWithRolesViewModel.cs
using LMS.Models;
using System.Collections.Generic;

namespace LMS.Models.ViewModels
{
    public class UserWithRolesViewModel
    {
        public ApplicationUser User { get; set; }
        public IList<string> Roles { get; set; }
    }
}
