﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LMS.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; }

        [Required, MaxLength(50)]
        public string ISBN { get; set; }

        [Required, MaxLength(200)]
        public string Author { get; set; }
    }
}
