﻿using LMS.Data;
using LMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LMS.Controllers
{
    [Route("library")]
    public class LibraryController : Controller
    {
        private readonly AppDBContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public LibraryController(AppDBContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: /library or /library/available
        [HttpGet("")]
        [HttpGet("available")]
        public async Task<IActionResult> Available(string searchQuery)
        {
            var query = _context.Books.AsQueryable();

            // Exclude lent books for logged-in users
            query = query.Where(b => !_context.BookLends
                .Any(l => l.BookID == b.BookID && l.ReturnDate == null));

            // Apply search
            if (!string.IsNullOrEmpty(searchQuery))
            {
                searchQuery = searchQuery.ToLower();
                query = query.Where(b =>
                    b.Title.ToLower().Contains(searchQuery) ||
                    b.ISBN.ToLower().Contains(searchQuery) ||
                    b.Author.ToLower().Contains(searchQuery)
                );
            }

            var books = await query.OrderBy(b => b.Title).ToListAsync();
            ViewBag.SearchQuery = searchQuery;

            return View(books);
        }

        // POST: /library/lend
        [HttpPost("lend")]
        [Authorize] // Only logged-in users can lend
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Lend(int bookId)
        {
            var userId = _userManager.GetUserId(User);

            // Check if the user has already borrowed this book and not returned
            var alreadyLent = await _context.BookLends
                .AnyAsync(l => l.BookID == bookId && l.UserID == userId && l.ReturnDate == null);

            if (alreadyLent)
            {
                TempData["error"] = "You have already borrowed this book!";
                return RedirectToAction("Available");
            }

            var lend = new BookLend
            {
                BookID = bookId,
                UserID = userId,
                LendDate = DateTime.Now
            };

            _context.BookLends.Add(lend);
            await _context.SaveChangesAsync();

            TempData["success"] = "Book borrowed successfully!";
            return RedirectToAction("Available");
        }

        // GET: /library/my-books
        [HttpGet("my-books")]
        [Authorize]
        public async Task<IActionResult> MyBooks()
        {
            var userId = _userManager.GetUserId(User);

            var lends = await _context.BookLends
                .Include(l => l.Book)
                .Where(l => l.UserID == userId && l.ReturnDate == null)
                .OrderByDescending(l => l.LendDate)
                .ToListAsync();

            return View(lends);
        }

        // POST: /library/return
        [HttpPost("return")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Return(int lendId)
        {
            var userId = _userManager.GetUserId(User);

            var lend = await _context.BookLends
                .FirstOrDefaultAsync(l => l.LendID == lendId && l.UserID == userId && l.ReturnDate == null);

            if (lend == null)
            {
                TempData["error"] = "Book not found or already returned!";
                return RedirectToAction("MyBooks");
            }

            lend.ReturnDate = DateTime.Now;
            _context.BookLends.Update(lend);
            await _context.SaveChangesAsync();

            TempData["success"] = "Book returned successfully!";
            return RedirectToAction("MyBooks");
        }
    }
}
