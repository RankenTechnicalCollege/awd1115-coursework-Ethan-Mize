using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Views.Library
{
    public class MyBooksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
