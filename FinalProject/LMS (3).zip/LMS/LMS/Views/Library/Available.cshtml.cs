using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Views.Library
{
    public class AvailableModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
