﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using LMS.Models;
using LMS.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace LMS.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    [Route("admin/users")]
    public class AdminController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AdminController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // GET: admin/users
        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var list = new List<UserWithRolesViewModel>();

            foreach (var user in _userManager.Users.ToList())
            {
                var roles = await _userManager.GetRolesAsync(user);
                list.Add(new UserWithRolesViewModel { User = user, Roles = roles });
            }

            return View(list);
        }

        // POST: admin/users/create-admin-role
        [HttpPost("create-admin-role")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateAdminRole()
        {
            if (!await _roleManager.RoleExistsAsync("Admin"))
                await _roleManager.CreateAsync(new IdentityRole("Admin"));

            TempData["success"] = "Admin role created (or already exists).";
            return RedirectToAction("Index");
        }

        // POST: admin/users/delete/{id}
        [HttpPost("delete/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteUser(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                TempData["error"] = "User not found.";
                return RedirectToAction("Index");
            }

            var result = await _userManager.DeleteAsync(user);
            TempData["success"] = result.Succeeded ? "User deleted." : "Failed to delete user.";
            return RedirectToAction("Index");
        }

        // POST: admin/users/add-admin/{id}
        [HttpPost("add-admin/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdmin(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                TempData["error"] = "User not found.";
                return RedirectToAction("Index");
            }

            if (!await _roleManager.RoleExistsAsync("Admin"))
                await _roleManager.CreateAsync(new IdentityRole("Admin"));

            await _userManager.AddToRoleAsync(user, "Admin");
            TempData["success"] = "User added to Admin role.";
            return RedirectToAction("Index");
        }

        // POST: admin/users/remove-admin/{id}
        [HttpPost("remove-admin/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveAdmin(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                TempData["error"] = "User not found.";
                return RedirectToAction("Index");
            }

            await _userManager.RemoveFromRoleAsync(user, "Admin");
            TempData["warning"] = "Admin role removed from user.";
            return RedirectToAction("Index");
        }
    }
}
