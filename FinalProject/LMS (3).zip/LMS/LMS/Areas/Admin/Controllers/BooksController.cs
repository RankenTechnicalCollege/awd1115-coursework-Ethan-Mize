﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using LMS.Models;
using LMS.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace LMS.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    [Route("admin/books")]
    public class BooksController : Controller
    {
        private readonly AppDBContext _context;

        public BooksController(AppDBContext context)
        {
            _context = context;
        }

        // GET: admin/books
        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var books = await _context.Books.ToListAsync();
            return View(books);
        }

        // GET: admin/books/create
        [HttpGet("create")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: admin/books/create
        [HttpPost("create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Book model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            _context.Books.Add(model);
            await _context.SaveChangesAsync();

            TempData["success"] = "Book added successfully!";
            return RedirectToAction("Index");
        }

        [HttpGet("edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            ModelState.Clear(); // THIS IS THE FIX

            return View(book);
        }

        // POST: admin/books/edit/{id}
        [HttpPost("edit/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Book model)
        {
            if (id != model.BookID) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            _context.Books.Update(model);
            await _context.SaveChangesAsync();

            TempData["success"] = "Book updated successfully!";
            return RedirectToAction("Index");
        }

        // POST: admin/books/delete/{id}
        [HttpPost("delete/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                TempData["error"] = "Book not found!";
                return RedirectToAction("Index");
            }

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            TempData["warning"] = "Book deleted.";
            return RedirectToAction("Index");
        }

        [HttpGet("lent")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> LentBooks()
        {
            var lends = await _context.BookLends
                .Include(l => l.Book)
                .Include(l => l.User)
                .Where(l => l.ReturnDate == null) // only currently lent
                .OrderByDescending(l => l.LendDate)
                .ToListAsync();

            return View(lends);
        }
    }
}
