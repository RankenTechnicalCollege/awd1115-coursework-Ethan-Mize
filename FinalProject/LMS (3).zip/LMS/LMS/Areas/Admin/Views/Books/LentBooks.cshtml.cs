using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Areas.Admin.Views.Books
{
    public class LentBooksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
