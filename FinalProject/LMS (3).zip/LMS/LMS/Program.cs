using LMS.Data;
using LMS.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Routing;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------
// Add services to the container
// ---------------------------------------------------
builder.Services.AddControllersWithViews();

// Register DbContext with SQL Server
builder.Services.AddDbContext<AppDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// ---------------------------------------------------
// 🔥 ADD IDENTITY (Required for Admin/User Roles)
// ---------------------------------------------------
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 6;
    options.Password.RequireUppercase = true;
    options.Password.RequireLowercase = true;
})
    .AddEntityFrameworkStores<AppDBContext>()
    .AddDefaultTokenProviders()
    .AddDefaultUI(); // This is fine now with Microsoft.AspNetCore.Identity.UI

// ---------------------------------------------------
// Authentication + Authorization
// ---------------------------------------------------
builder.Services.AddAuthentication();
builder.Services.AddAuthorization();

// ---------------------------------------------------
// Lowercase URLs + Trailing Slash
// ---------------------------------------------------
builder.Services.Configure<RouteOptions>(options =>
{
    options.LowercaseUrls = true;
    options.AppendTrailingSlash = true;
});

var app = builder.Build();

// ---------------------------------------------------
// 🔥 SEED ADMIN ROLE + ACCOUNT ON STARTUP
// ---------------------------------------------------
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    await SeedData.SeedRolesAndAdminAsync(services);
}

// ---------------------------------------------------
// Configure the HTTP request pipeline
// ---------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Authentication must come before Authorization
app.UseAuthentication();
app.UseAuthorization();

// ---------------------------------------------------
// Map Razor Pages (Required for Identity UI)
// ---------------------------------------------------
app.MapRazorPages(); // <-- Essential for /Identity/... pages

// Map Area routes (Admin)
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller}/{action=Index}/{id?}");

// Default MVC route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Library}/{action=Available}/{id?}");

// Optional redirect from root "/" to /library/available
app.MapGet("/", async context =>
{
    context.Response.Redirect("/library/available");
    await Task.CompletedTask;
});

app.Run();
