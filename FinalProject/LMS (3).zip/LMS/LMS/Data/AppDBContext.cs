﻿using LMS.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LMS.Data
{
    public class AppDBContext : IdentityDbContext<ApplicationUser>
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        // Only Books table remains
        public DbSet<Book> Books { get; set; }

        public DbSet<BookLend> BookLends { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Required for Identity

            // Seed Books (Author is now plain text)
            modelBuilder.Entity<Book>().HasData(
                new Book
                {
                    BookID = 1,
                    Title = "The Great Gatsby",
                    ISBN = "9780743273565",
                    Author = "F. Scott Fitzgerald"
                },
                new Book
                {
                    BookID = 2,
                    Title = "To Kill a Mockingbird",
                    ISBN = "9780061120084",
                    Author = "Harper Lee"
                },
                new Book
                {
                    BookID = 3,
                    Title = "1984",
                    ISBN = "9780451524935",
                    Author = "George Orwell"
                },
                new Book
                {
                    BookID = 4,
                    Title = "Pride and Prejudice",
                    ISBN = "9781503290563",
                    Author = "Jane Austen"
                },
                new Book
                {
                    BookID = 5,
                    Title = "The Catcher in the Rye",
                    ISBN = "9780316769488",
                    Author = "J.D. Salinger"
                }
            );
        }
    }
}
