﻿using LMS.Data;
using LMS.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace LMS.Controllers
{
    [Route("books")]
    public class BookController : Controller
    {
        private readonly AppDBContext _context;
      
        public BookController(AppDBContext context)
        {
            _context = context;
        }

        // GET: Books
        [HttpGet("")]
        public async Task<IActionResult> List()
        {
            var books = await _context.Books.ToListAsync();
            return View(books);
        }

        // GET: Books/add
        [HttpGet("add/")]
        public IActionResult Add()
        {
            return View();
        }

        // POST: Books/Create
        [HttpPost("add/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Books.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(List));
            }
            return View(book);
        }

        // DELETE => /books/delete/{id}/{slug}/
        [HttpGet("delete/{id:int}/{slug}/")]
        public async Task<IActionResult> Delete(int id, string slug)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookID == id);
            if (book == null) return NotFound();

            return View(book);
        }

        [HttpPost("delete/{id:int}/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book != null)
            {
                _context.Books.Remove(book);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(List));
        }

        // EDIT => /books/edit/{id}/{slug}/
        [HttpGet("edit/{id:int}/{slug}/")]
        public async Task<IActionResult> Edit(int id, string slug)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            return View(book);
        }

        [HttpPost("edit/{id:int}/{slug}/")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Book book)
        {
            if (id != book.BookID) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(book);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.BookID)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(List));
            }
            return View(book);
        }


        // DETAILS => /books/{id}/{slug}/
        [HttpGet("{id:int}/{slug}/")]
        public async Task<IActionResult> Details(int id, string slug)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookID == id);
            if (book == null) return NotFound();

            // Ensure slug matches title, else redirect
            var expectedSlug = ToSlug(book.Title);
            if (slug != expectedSlug)
                return RedirectToAction(nameof(Details), new { id, slug = expectedSlug });

            return View(book);
        }

        // Helper method to check if book exists
        private bool BookExists(int id)
        {
            return _context.Books.Any(b => b.BookID == id);
        }
        private string ToSlug(string title)
        {
            if (string.IsNullOrEmpty(title)) return "";
            return title
                .ToLower()
                .Replace(" ", "-")
                .Replace(".", "")
                .Replace(",", "")
                .Replace(":", "")
                .Replace(";", "")
                .Replace("!", "")
                .Replace("?", "");
        }
    }
}
