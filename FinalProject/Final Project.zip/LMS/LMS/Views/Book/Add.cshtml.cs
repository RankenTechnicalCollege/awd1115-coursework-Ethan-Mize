using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Views.Book
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
