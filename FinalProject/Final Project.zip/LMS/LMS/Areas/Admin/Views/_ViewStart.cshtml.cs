using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMS.Areas.Admin.Views
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
